﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace databl
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
      
        DataTable dtteammatch = new DataTable();
        DataTable matchvs = new DataTable();
        DataTable mdetail = new DataTable();
        DataTable dtteamhome = new DataTable();
        DataTable dtteamaway = new DataTable();
      
   
       
        MySqlConnection sqlConnection;
        MySqlCommand mysqlcommand;
        MySqlDataAdapter MySqlDataAdapter;
        string teammatch = "";
        string vsmatch = "";
        string matchdetail = "";
        string teamhome = "";
        string teamaway = "";

        string connection = "server=localhost;uid=root;pwd=;database=premier_league";
        private void playerDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            panel1.Show();
            panel1.Visible = true;

            string connetionstring = null;
            MySqlConnection cnn; //connection ini untuk conect in visual studio dan mysql
            MySqlCommand cmm; // commend untuk query 
            MySqlDataAdapter adp; // untuk baca query nya 
            DataTable dt;
            connetionstring = "server=localhost;database=premier_league;uid=root;pwd=''";
            cnn = new MySqlConnection(connetionstring);
            cmm = new MySqlCommand("select m.manager_id as ID,m.manager_name as Name,concat(if (m.working=0,'Available',if(m.manager_id=t.assmanager_id,'Asisten Manager','Manager')),' ',if(m.working=1,t.team_name,'')) as Status from manager m left join team t on m.manager_id=t.assmanager_id or m.manager_id=t.manager_id where m.delete=0 order by ID asc", cnn);
            adp = new MySqlDataAdapter(cmm);
            dt = new DataTable();

            try

            {
                dt = new DataTable();
                connetionstring = "server=localhost;database=premier_league;uid=root;pwd=''";
                //cnn = new MySqlConnection(connetionstring);
                cmm = new MySqlCommand("select team_id,team_name from team t", cnn);
                adp = new MySqlDataAdapter(cmm);
                cnn.Open();
                adp.Fill(dt);
                comboBox1.DataSource = dt;
                comboBox1.DisplayMember = "team_name";
                comboBox1.ValueMember = "team_id";
                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection !");
            }
            cnn.Close();
            panel1.Show();

        }

       

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            string connetionstring = null;
            MySqlConnection cnn; //connection ini untuk conect in visual studio dan mysql
            MySqlCommand cmm; // commend untuk query 
            MySqlDataAdapter adp; // untuk baca query nya 
            DataTable dt;
            connetionstring = "server=localhost;database=premier_league;uid=root;pwd=''";
            cnn = new MySqlConnection(connetionstring);
            cmm = new MySqlCommand("select m.manager_id as ID,m.manager_name as Name,concat(if (m.working=0,'Available',if(m.manager_id=t.assmanager_id,'Asisten Manager','Manager')),' ',if(m.working=1,t.team_name,'')) as Status from manager m left join team t on m.manager_id=t.assmanager_id or m.manager_id=t.manager_id where m.delete=0 order by ID asc", cnn);
            adp = new MySqlDataAdapter(cmm);
            dt = new DataTable();

           
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
         
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

       

        private void matchDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible= false;
            panel2.Show();
            panel2.Visible=true;

            //string connetionstring = null;
            //MySqlConnection cnn; //connection ini untuk conect in visual studio dan mysql
            //MySqlCommand cmm; // commend untuk query 
            //MySqlDataAdapter adp; // untuk baca query nya 
            //DataTable dt;
            //connetionstring = "server=localhost;database=premier_league;uid=root;pwd=''";
            //cnn = new MySqlConnection(connetionstring);
            //cmm = new MySqlCommand("select m.manager_id as ID,m.manager_name as Name,concat(if (m.working=0,'Available',if(m.manager_id=t.assmanager_id,'Asisten Manager','Manager')),' ',if(m.working=1,t.team_name,'')) as Status from manager m left join team t on m.manager_id=t.assmanager_id or m.manager_id=t.manager_id where m.delete=0 order by ID asc", cnn);
            //adp = new MySqlDataAdapter(cmm);
            //dt = new DataTable();

            //try

            //{
            //    dt = new DataTable();
            //    connetionstring = "server=localhost;database=premier_league;uid=root;pwd=''";
            //    //cnn = new MySqlConnection(connetionstring);
            //    cmm = new MySqlCommand("select team_id,team_name from team t", cnn);

            //    adp = new MySqlDataAdapter(cmm);
            //    cnn.Open();
            //    adp.Fill(dt);
            //    comboBox3.DataSource = dt;
            //    comboBox3.DisplayMember = "team_name";
            //    comboBox3.ValueMember = "team_id";
            //    cnn.Close();
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show("Can not open connection !");
            //}
            teammatch = "select team_id as 'ID',team_name as'Team Name' from team";
            sqlConnection = new MySqlConnection(connection);
            mysqlcommand = new MySqlCommand(teammatch, sqlConnection);
            MySqlDataAdapter = new MySqlDataAdapter(mysqlcommand);
            MySqlDataAdapter.Fill(dtteammatch);
            comboBox3.DataSource = dtteammatch;
            comboBox3.ValueMember = "ID";
            comboBox3.DisplayMember = "Team Name";

            //string connetionstring = null;
            //MySqlConnection cnn; //connection ini untuk conect in visual studio dan mysql
            //MySqlCommand cmm; // commend untuk query 
            //MySqlDataAdapter adp; // untuk baca query nya 
            //DataTable dt;






        }

        

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void toolStripComboBox3_Click(object sender, EventArgs e)
        {

        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            string connetionstring = null;
            MySqlConnection cnn; //connection ini untuk conect in visual studio dan mysql
            MySqlCommand cmm; // commend untuk query 
            MySqlDataAdapter adp; // untuk baca query nya 
            DataTable dt;
            try

            {

                dt = new DataTable();
                connetionstring = "server=localhost;database=premier_league;uid=root;pwd=''";
                cnn = new MySqlConnection(connetionstring);
                cmm = new MySqlCommand("select player_id,player_name from team t,player p where p.team_id=t.team_id and t.team_id=('" + comboBox1.SelectedValue + "')", cnn);
                adp = new MySqlDataAdapter(cmm);
                cnn.Open();
                adp.Fill(dt);
                comboBox2.DataSource = dt;
                comboBox2.DisplayMember = "player_name";
                comboBox2.ValueMember = "player_id";
                cnn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection !");
            }
        }

        private void comboBox2_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            string connetionstring = null;
            MySqlConnection cnn; //connection ini untuk conect in visual studio dan mysql
            MySqlCommand cmm; // commend untuk query 
            MySqlDataAdapter adp; // untuk baca query nya 
            DataTable dt;
            try

            {

                dt = new DataTable();
                connetionstring = "server=localhost;database=premier_league;uid=root;pwd=''";
                cnn = new MySqlConnection(connetionstring);
                cmm = new MySqlCommand("select p.player_name,team_number,t.team_name,n.nation,p.playing_pos,sum(if (d.type='CY',1,0)) as 'cy',sum(if(d.type='CR',1,0)) as'cr',sum(if(d.type='GO',1,0)) as 'go', sum(if(d.type='PM',1,0)) as 'pm'from player p,team t,dmatch d,nationality n where p.team_id=t.team_id and d.player_id=p.player_id and p.nationality_id=n.nationality_id and d.team_id=t.team_id and p.player_id=('" +comboBox2.SelectedValue + "');", cnn);
                adp = new MySqlDataAdapter(cmm);
                cnn.Open();
                adp.Fill(dt);
                string playername = string.Empty;
                string playerteam = string.Empty;
                string position = string.Empty;
                string nationality = string.Empty;
                string squadnumber= string.Empty;
                string redcard = "0";
                string goalscore  = "0";
                string penaltymiss = "0";
                string yellowcard = "0";
                if (dt.Rows.Count > 0)
                    playername = dt.Rows[0]["player_name"].ToString();
                playerteam = dt.Rows[0]["team_name"].ToString();
                position = dt.Rows[0]["playing_pos"].ToString();
               
                nationality = dt.Rows[0]["nation"].ToString();
                
                squadnumber = dt.Rows[0]["team_number"].ToString();
                redcard = dt.Rows[0]["cr"].ToString();
                goalscore = dt.Rows[0]["go"].ToString();
                penaltymiss = dt.Rows[0]["pm"].ToString();
                yellowcard = dt.Rows[0]["cy"].ToString();
                label10.Text = playername;
                label11.Text = playerteam;
                label13.Text= position;
                label12.Text = nationality;
                label14.Text = squadnumber;
                label17.Text = "0";
                label15.Text= "0";
                label16.Text = "0";
                label18.Text = "0";
                if (redcard.Length>=1)
                {
                    label17.Text = redcard;
                }
                if (goalscore.Length >= 1)
                {
                    label15.Text = goalscore;
                }
                if (penaltymiss.Length >= 1)
                {
                    label16.Text = penaltymiss;
                }
                if (yellowcard.Length >= 1)
                {
                    label18.Text = yellowcard;
                }
                cnn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection !");
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            matchvs.Clear();
            vsmatch = "select t1.team_id as 'teamid', m.match_id as'matchid',m.match_date as'match date',t1.team_name as'home team',t2.team_name as'away team' from `match`m,dmatch d,team t1,team t2 where m.team_home=t1.team_id and m.team_away=t2.team_id and m.match_id=d.match_id and (t1.team_id=" + $"'{comboBox3.SelectedValue.ToString()}'or t2.team_id=" + $"'{comboBox3.SelectedValue.ToString()}') group by m.match_id;";
            sqlConnection = new MySqlConnection(connection);
            mysqlcommand = new MySqlCommand(vsmatch, sqlConnection);
            MySqlDataAdapter = new MySqlDataAdapter(mysqlcommand);
            MySqlDataAdapter.Fill(matchvs);
            comboBox4.DataSource = matchvs;
            comboBox4.ValueMember = "matchid";
            comboBox4.DisplayMember = "matchid";
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

  

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtteamaway.Clear();
            dtteamhome.Clear();
            mdetail.Clear();
            matchdetail = "select d.`Minute` as'Minute',t.team_name as'Team Name',p.player_name as 'playername',if(d.type='CY','Yellow Card',if(d.type='CR','Red Card',if(d.type='GO','Goal',if(d.type='GW','OwnGoal',if(d.type='Gp','Goal Penalty','Penalty Miss'))))) as 'warna kartu' from dmatch d,team t,player p where d.team_id=t.team_id and d.player_id=p.player_id and d.match_id=" + $"'{comboBox4.SelectedValue.ToString()}';";
            sqlConnection = new MySqlConnection(connection);
            mysqlcommand = new MySqlCommand(matchdetail, sqlConnection);
            MySqlDataAdapter = new MySqlDataAdapter(mysqlcommand);
            MySqlDataAdapter.Fill(mdetail);
            dataGridView1.DataSource = mdetail;
            teamaway = "select t.team_name as'Away Team',p.player_name as 'Away Player',p.playing_pos as'position'from `match`m,team t,player p where p.team_id=t.team_id and t.team_id=m.team_away and m.match_id=" + $"'{comboBox4.SelectedValue.ToString()}';";
            sqlConnection = new MySqlConnection(connection);
            mysqlcommand = new MySqlCommand(teamaway, sqlConnection);
            MySqlDataAdapter = new MySqlDataAdapter(mysqlcommand);
            MySqlDataAdapter.Fill(dtteamaway);
            dataGridView3.DataSource = dtteamaway;
            teamhome = "select t.team_name as'Home Team',p.player_name as 'Home Player',p.playing_pos as'position'from `match`m,team t,player p where p.team_id=t.team_id and t.team_id=m.team_home and m.match_id=" + $"'{comboBox4.SelectedValue.ToString()}';";
            sqlConnection = new MySqlConnection(connection);
            mysqlcommand = new MySqlCommand(teamhome, sqlConnection);
            MySqlDataAdapter = new MySqlDataAdapter(mysqlcommand);
            MySqlDataAdapter.Fill(dtteamhome);
            dataGridView2.DataSource = dtteamhome;

        }
    }
}
